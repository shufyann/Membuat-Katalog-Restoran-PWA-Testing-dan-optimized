import RestaurantSource from '../../data/restaurant-source';
import { createRestaurant } from '../templates/templates';

const Home = {
  async render() {
    return `
      <div id="itemList" class="item-list"> </div>
    `;
  },

  async afterRender() {
    const restaurants = await RestaurantSource.home();
    const restaurantsContainer = document.querySelector('#itemList');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurant(restaurant);
    });
  },
};

export default Home;
