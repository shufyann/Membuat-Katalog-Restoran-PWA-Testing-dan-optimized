import { createRestaurant } from '../../templates/templates';

class FavoriteRestaurantSearchView {
  getTemplate() {
    return `
      <div class="content">
      <h2 class="search-heading">Restaurant Kesukaanmu</h2>
      <div id="search-container">
                <input type="text" id="query" placeholder="Search Restaurant">
                <button id="btn-search" type="submit">Search</button>
            </div> 
        <div id="restaurants" class="restaurants">
        </div>
      </div>
   `;
  }

  runWhenUserIsSearching(callback) {
    document.getElementById('query').addEventListener('change', (event) => {
      callback(event.target.value);
    });
  }

  showRestaurants(Restaurants) {
    this.showFavoriteRestaurants(Restaurants);
  }

  showFavoriteRestaurants(Restaurants = []) {
    let html;
    if (Restaurants.length) {
      html = Restaurants.reduce((carry, Restaurant) => carry.concat(createRestaurant(Restaurant)), '');
    } else {
      html = this._getEmptyRestaurantTemplate();
    }

    document.getElementById('restaurants').innerHTML = html;

    document.getElementById('restaurants').dispatchEvent(new Event('restaurants:updated'));
  }

  _getEmptyRestaurantTemplate() {
    return '<div class="restaurant-item__not__found restaurant__not__found">Tidak ada restaurant untuk ditampilkan</div>';
  }
}

export default FavoriteRestaurantSearchView;
