import UrlParser from '../../routes/url-parser';
import RestaurantSource from '../../data/restaurant-source';
import { createRestaurantDetail, createMenu, createReview } from '../templates/templates';
import LikeButtonInitiator from '../../utils/favorite-button';

const Detail = {
  async render() {
    return `
      <div id="detail" class="detail"> </div>
      <div id="likeButtonContainer"></div>
    `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const restaurant = await RestaurantSource.detail(url.id);
    const restaurantContainer = document.querySelector('#detail');
    restaurantContainer.innerHTML = createRestaurantDetail(restaurant);

    LikeButtonInitiator.init({
      likeButtonContainer: document.querySelector('#likeButtonContainer'),
      restaurant: {
        id: restaurant.id,
        name: restaurant.name,
        city: restaurant.city,
        description: restaurant.description,
        pictureId: restaurant.pictureId,
        rating: restaurant.rating,
      },
    });

    const foodsContainer = document.querySelector('#foods');
    const menuFoods = restaurant.menus.foods;
    menuFoods.forEach((food) => {
      foodsContainer.innerHTML += createMenu(food);
    });

    const drinksContainer = document.querySelector('#drinks');
    const menuDrinks = restaurant.menus.drinks;
    menuDrinks.forEach((drink) => {
      drinksContainer.innerHTML += createMenu(drink);
    });

    const reviewContainer = document.querySelector('#reviewRestaurant');
    const reviews = restaurant.customerReviews;
    reviews.forEach((review) => {
      reviewContainer.innerHTML += createReview(review);
    });
  },
};
export default Detail;
