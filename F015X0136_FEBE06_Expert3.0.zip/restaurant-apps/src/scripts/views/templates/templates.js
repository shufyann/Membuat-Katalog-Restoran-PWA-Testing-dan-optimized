import CONFIG from '../../globals/config';

const createRestaurant = (restaurant) => `
    <div class="item" tabindex="0">
        <img class="lazyload" data-src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt="${restaurant.name}" />
        <h3 class="restaurant__title"><a href="/#/detail/${restaurant.id}">${restaurant.name}</a></h3>
        <p>${restaurant.rating} <span class="bintang">&#9733;</span></p>
        <p>${restaurant.city}</p>
    </div>
`;

const createRestaurantDetail = (restaurant) => `
    <div class="item" tabindex="0">
        <img class="lazyload" data-src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt="${restaurant.name}" />
        <h3 class="restaurant__title" ><a href="/#/detail/${restaurant.id}">${restaurant.name}</a></h3>
        <p>Rating : ${restaurant.rating} <span class="bintang">&#9733;</span></p>
        <p>Lokasi : ${restaurant.city}</p>
        <p class="text">${restaurant.description}</p>
      <div class="menu">
        <h3> Menu Restaurant </h3>
        <div class="menu-restaurant">
            <div>
                <p class="judul"> Makanan </p>
                <div class="foods" id="foods"></div>
            </div>
            <div>
                <p class="judul"> Minuman </p>
                <div class="drinks" id="drinks"></div>
            </div>
        </div>
    </div >
    <div class="review-container">
        <h3> Review </h3>
        <div id="reviewRestaurant" class="review-restaurant"></div>
    </div>
`;

const createMenu = (menu) => `
    <p>${menu.name}</p>
`;

const createReview = (customer) => `
    <div id="review" class="review">
        <p>${customer.name}</p>
        <p class="review-date">${customer.date}</p>
        <p class="text"
        >${customer.review}</p>
    </div>
`;

const likeButton = () => `
  <button aria-label="like this restaurant" id="likeButton" class="like">
    <i class="fa fa-heart-o" aria-hidden="true"></i>
  </button>
`;

const likedButton = () => `
  <button aria-label="unlike this restaurant" id="likeButton" class="like">
    <i class="fa fa-heart" aria-hidden="true"></i>
  </button>
`;

export {
  createRestaurant, createRestaurantDetail, likeButton, likedButton, createMenu, createReview,
};
