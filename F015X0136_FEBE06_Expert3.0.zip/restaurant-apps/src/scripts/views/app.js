import DrawerInitiator from '../utils/drawer-initiator';
import UrlParser from '../routes/url-parser';
import routes from '../routes/routes';
// import CONFIG from '../globals/config';
// import filter from 'lodash.filter';
// import { createReview } from './templates/templates';

class App {
  constructor({ button, drawer, content }) {
    this.button = button;
    this.drawer = drawer;
    this.content = content;

    this.initialAppShell();
  }

  initialAppShell() {
    DrawerInitiator.init({
      button: this.button,
      drawer: this.drawer,
      content: this.content,
    });
  }

  async renderPage() {
    const url = UrlParser.parseActiveUrlWithCombiner();
    const page = routes[url];
    // const review = document.querySelector('#review');
    // // filter(CONFIG, review.id === 'review' ? {} : { type: review.id })
    // //   .forEach(createReview);

    const skipLinkElem = document.querySelector('.skip-link');
    skipLinkElem.addEventListener('click', (event) => {
      event.preventDefault();
      document.querySelector('#content').focus();
    });

    this.content.innerHTML = await page.render();
    await page.afterRender();
  }
}

export default App;
