// eslint-disable-next-line import/no-unresolved
import LikeButtonInitiator from '../../src/scripts/utils/favorite-button';
import FavoriteRestaurantIdb from '../../src/scripts/data/favorite-restourant';

const createLikeButtonInitiatorWithRestaurant = async (restaurant) => {
  await LikeButtonInitiator.init({
    likeButtonContainer: document.querySelector('#likeButtonContainer'),
    favoriteRestaurants: FavoriteRestaurantIdb,
    restaurant,
  });
};

export { createLikeButtonInitiatorWithRestaurant };
